function selectRole(role){
  if(role){
    $("#role-selector").val("TRUE");
  }else{
    $("#role-selector").val("FALSE");  
  }
}
