function selectCity(id){
	$("#city-selector").val(id);
}
